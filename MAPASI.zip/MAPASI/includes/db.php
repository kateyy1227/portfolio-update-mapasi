<?php

$con = mysqli_connect("localhost", "root", "", "mapasi");

if (!$con) {
    die("Not Connected");

}

?>
