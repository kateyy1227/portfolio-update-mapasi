
<?php require_once "includes/header.php"; ?>
<?php require_once "includes/nav.php"; ?>
<?php require_once "includes/intro.php"; ?>
<?php require_once "includes/db.php"; ?>



    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 2px;
            padding: 50px;
            background-color: #f0f0f0;
        }

        .portfolio-container {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin-top: 13%;
            
            
        }

        .portfolio-content {
            display: flex;
            width: 100%;
            max-width: 1200px; /* Adjust the maximum width as needed */
            background-color: #fff;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .portfolio-image {
            flex: 1;
            max-width: 40%;
            overflow: hidden;
        }

        .portfolio-image img {
            width: 100%;
            height: auto;
            border-radius: 8px 0 0 8px;
        }

        .portfolio-description {
            flex: 1;
            padding: 20px;
        }

        .description-title {
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 10px;
        }

        .description-text {
            font-size: 16px;
            line-height: 1.6;
        }

        .skills-container {
            width: 20%;
            max-width: 400px;
            background-color: #f9f9f9;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-top: 0%;
            margin-left: 20px;
            padding: 20px;
          
        }

        .skills-title {
            font-size: 20px;
            font-weight: bold;
            margin-bottom: 10px;
            text-align: center;
        }

        .skill-item {
            margin-bottom: 16px;
            text-align: center;
        }

        .progress-circle {
            position: relative;
            width: 70px;
            height: 70px;
            border-radius: 50%;
            background-color: #e0e0e0;
            margin: 0 auto;
        }

        .progress-circle::before {
            content: '';
            position: absolute;
            width: 100%;
            height: 100%;
            border-radius: 50%;
            background: conic-gradient(#3498db 0%, #3498db var(--percent), transparent var(--percent), transparent 100%);
            --percent: 0;
        }

        .progress-text {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            font-size: 16px;
            font-weight: bold;
            color: #3498db;
        }

      

      .card-list {
          text-align: center;
          padding: 20px;
      }

      .card-list h2 {
          font-size: 28px;
          margin-bottom: 20px;
      }



      .card {
          list-style: none;
          display: inline-block;
          width: 300px;
          margin: 0 10px;
          box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
          border-radius: 8px;
          overflow: hidden;
          transition: transform 0.3s ease;
      }

      .card:hover {
          transform: scale(1.05);
      }

      .card-image img {
          width: 100%;
          height: auto;
      }

      .card-description {
          padding: 15px;
          background-color: #fff;
      }

      .card-description h2 {
          font-size: 18px;
          margin-bottom: 5px;
      }

      .card-description p {
          font-size: 14px;
          color: #555;
      }

    
      .skills {
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
}

.skill {
  width: 30%;
  margin: 10px;
  padding: 10px;
  text-align: center;
  background-color: #f0f0f0;
  border-radius: 5px;
}

@media only screen and (max-width: 768px) {
  .skill {
    width: 45%;
  }
}

@media only screen and (max-width: 480px) {
  .skill {
    width: 100%;
  }
}
    </style>





    <div class="portfolio-container">
        <div class="portfolio-content">
            <div class="portfolio-image">
                <img src="images/margo.jpg" alt="Your Name">
            </div>
            <div class="portfolio-description">
                <h1 class="description-title">About Me</h1>
                <p class="description-text">
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis auctor urna non sem semper, ac bibendum velit rhoncus. Integer tincidunt lectus a massa lacinia, a ultrices nunc semper. In hac habitasse platea dictumst.
                </p>
            </div>
        </div>
        <div class="skills-container">
            <h2 class="skills-title">Skills</h2>
            <div class="skill-item">
                <div class="progress-circle" style="--percent: 80%;">
                    <div class="progress-text">80%</div>
                </div>
                <p>Web Development</p>
            </div>
            <div class="skill-item">
                <div class="progress-circle" style="--percent: 60%;">
                    <div class="progress-text">60%</div>
                </div>
                <p>JavaScript</p>
            </div>
            <div class="skill-item">
                <div class="progress-circle" style="--percent: 75%;">
                    <div class="progress-text">75%</div>
                </div>
                <p>HTML/CSS</p>
            </div>
            <!-- Add more skills as needed -->
        </div>
    </div>


  
    

  

<div class="card-list">
  <h2><span>Projects</span></h2>

  <ul>
    <li class="card">
      <a class="card-image" href="https://inlovewithaghost.bandcamp.com/album/lets-go" data-image-full="https://s3-us-west-2.amazonaws.com/s.cdpn.io/310408/lets-go-500.jpg">
        <img src="images/Death Valley.png" alt="let's go">
      </a>
      <div class="card-description">
        <h2>Poster</h2>
        <p>Death Valley</p>
      </div>
    </li>

    <li class="card">
      <a class="card-image" href="https://inlovewithaghost.bandcamp.com/album/lets-go" data-image-full="https://s3-us-west-2.amazonaws.com/s.cdpn.io/310408/lets-go-500.jpg">
        <img src="images/poster.png" alt="let's go">
      </a>
      <div class="card-description">
        <h2>Graphic Design</h2>
        <p>Poster</p>
      </div>
    </li>

    <li class="card">
      <a class="card-image" href="https://inlovewithaghost.bandcamp.com/album/lets-go" data-image-full="https://s3-us-west-2.amazonaws.com/s.cdpn.io/310408/lets-go-500.jpg">
        <img src="images/kopi.png" alt="let's go">
      </a>
      <div class="card-description">
        <h2>Graphic Design</h2>
        <p>Poster Ads</p>
      </div>
    </li>


    <li class="card">
      <a class="card-image" href="https://inlovewithaghost.bandcamp.com/album/lets-go" data-image-full="https://s3-us-west-2.amazonaws.com/s.cdpn.io/310408/lets-go-500.jpg">
        <img src="images/kopi.png" alt="let's go">
      </a>
      <div class="card-description">
        <h2>Graphic Design</h2>
        <p>Poster Ads</p>
      </div>
    </li>

    
  </ul>
</div>



         <div class="slider">
            <h2><span>Clients feedbacks</span></h2>
            <input type="radio" name="testimonial" id="t-1" />
            <input type="radio" name="testimonial" id="t-2" />
            <input type="radio" name="testimonial" id="t-3" checked />
            <input type="radio" name="testimonial" id="t-4" />
            <input type="radio" name="testimonial" id="t-5" />
            <div class="testimonials mb-8">
              <label class="item" for="t-1">
                <div class="mycard">
                  <p class="cardtitle">Arthur Nery</p>
                  <div>
                    <img src="images/test3.jpg" alt="nivel5" class="cardimg" />
                  </div>
                  <div>
                    <p class="carddescription">Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, et..</p>
                  </div>
                </div>
              </label>
              <label class="item" for="t-2">
                <div class="mycard">
                  <p class="cardtitle">Taylor Swift</p>
                  <div>
                    <img src="images/test3.jpg" alt="nivel5" class="cardimg" />
                  </div>
                  <div>
                    <p class="carddescription">Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, et..</p>
                  </div>
                </div>
              </label>
              <label class="item" for="t-3">
                <div class="mycard">
                  <p class="cardtitle">December Avenue</p>
                  <div>
                    <img src="images/test3.jpg" alt="nivel5" class="cardimg" />
                  </div>
                  <div>
                    <p class="carddescription">Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quos, et..</p>
                  </div>
                </div>
              </label>
              <label class="item" for="t-4">
                <div class="mycard">
                  <p class="cardtitle">Silent Sanctuary</p>
                  <div>
                    <img src="images/test3.jpg" alt="nivel5" class="cardimg" />
                  </div>
                  <div>
                    <p class="carddescription">Lorem ipsum dolor sit amet consectetur adipisicing elit. Eaque, odit..</p>
                  </div>
                </div>
              </label>
              <label class="item" for="t-5">
                <div class="mycard">
                  <p class="cardtitle">Hev abi</p>
                  <div>
                    <img src="images/test3.jpg" alt="nivel5" class="cardimg" />
                  </div>
                  <div>
                    <p class="carddescription">Lorem ipsum dolor sit amet consectetur adipisicing elit. Eaque, odit.</p>
                  </div>
                </div>
              </label>
            </div>
            <div class="dots">
              <label for="t-1"></label>
              <label for="t-2"></label>
              <label for="t-3"></label>
              <label for="t-4"></label>
              <label for="t-5"></label>
            </div>
          </div>







    </body>
</html>